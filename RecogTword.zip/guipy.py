# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\Nody\Desktop\alphabets\software_handwritten_scanner\gui.ui'
#
# Created by: PyQt5 UI code generator 5.9
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets 
from PyQt5.QtWidgets import QComboBox, QFileDialog
import os
import cv2
from keras.models import load_model
from keras.models import model_from_json
import sys

import numpy as np
from PIL import Image
from draggable_rectangle2 import Annotate

sys.setrecursionlimit(5000000)
#from draggable_rectangle2 import Annotate

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(571, 453)
        self.plots = None
        self.layout_option = ''
        self.path_string = ''
        self.fileName_choose = ''
        self.segement_data = []
        self.results = []
        self.str_results = []
        self.cwd = os.getcwd() # 获取当前程序文件位置
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(50, 70, 151, 41))
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.createnewlayout)
        
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(50, 130, 151, 41))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.saving_segment)
        
        self.pushButton_2_1 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2_1.setGeometry(QtCore.QRect(50, 180, 151, 41))
        self.pushButton_2_1.setObjectName("pushButton_2_1")
        self.pushButton_2_1.clicked.connect(self.load_layout)
        
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(50, 290, 151, 41))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.recognizing)
        
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setGeometry(QtCore.QRect(230, 235, 151, 30))
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_4.clicked.connect(self.readfile)

        self.pushButton_5 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_5.setGeometry(QtCore.QRect(400, 235, 151, 30))
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_5.clicked.connect(self.selectfile)
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 571, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.textEdit = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(230, 270, 311, 90))
        self.textEdit.setObjectName("textEdit")
        
# =============================================================================
#         combo.move(50, 50)
#         self.lb1.move(50, 150)
# 
#         combo.activated[str].connect(self.onActivated)
# 
#         self.setGeometry(300, 300, 300, 200)
#         self.setWindowTitle('组合框')        
#         self.show()
# =============================================================================

# =============================================================================
#         self.textEdit_2 = QtWidgets.QTextEdit(self.centralwidget)
#         self.textEdit_2.setGeometry(QtCore.QRect(230, 310, 311, 31))
#         self.textEdit_2.setObjectName("textEdit_2")
#         self.textEdit_3 = QtWidgets.QTextEdit(self.centralwidget)
#         self.textEdit_3.setGeometry(QtCore.QRect(230, 350, 311, 31))
#         self.textEdit_3.setObjectName("textEdit_3")
# =============================================================================
        self.textEdit_4 = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit_4.setGeometry(QtCore.QRect(230, 200, 311, 31))
        self.textEdit_4.setObjectName("textEdit_img_dir")
        
        self.combo = QComboBox(self.centralwidget)
        self.combo.setGeometry(QtCore.QRect(50, 240, 120, 40))
        self.combo.addItem('layout1')
        self.combo.activated[str].connect(self.onActivated)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton.setText(_translate("MainWindow", "create new layout"))
        self.pushButton_2.setText(_translate("MainWindow", "save new layout"))
        self.pushButton_2_1.setText(_translate("MainWindow", "load layout"))
        self.pushButton_3.setText(_translate("MainWindow", "start recognize"))
        self.pushButton_4.setText(_translate("MainWindow", "read file"))
    
    def createnewlayout(self):
        path_strings = self.textEdit_4.toPlainText()
        print(path_strings)
        self.plots = Annotate(str(path_strings))
        #self.segement_data.append(self.plots.segment_data)
        #print(self.segement_data)
        #path_strings = path_strings.split('\n')
        #print(path_strings)
        #for i in path_strings:
            #self.plots = Annotate(i)
            #self.plots = Annotate(r'C:\Users\Nody\Desktop\alphabets\software_scanner\software_handwritten_scanner\data\58b1d0aae1a24.png')
        
    
    def readfile(self):
        image_dir = self.textEdit_4.toPlainText()
        image_files = os.listdir(str(image_dir))
        self.path_string = ''
        for i in image_files:
            self.path_string += image_dir + "\\" + i +'\n'           
        self.textEdit.setText(self.path_string) 

    def onActivated(self, text):
        self.layout_option = str(text)
        print(self.layout_option)
    
    def show_result(self,array):
        mapping = [(0,'A'),(1,'B'),(2,'C'),(3,'D'),(4,'D'),(5,'E')]
        self.str_results = []
        for i in self.results:
            num_list = []
            for j in i:
                num_list.append(j)
                max_value = num_list.index(max(num_list))
            print(num_list.index(max(num_list)))
            for k in mapping:
                if max_value == k[0]:
                   self.str_results.append(k[1])
                   print(k[1])
        return self.str_results
            
        
    def recognizing(self):
        layout_name = self.layout_option
        layout_path = self.cwd  + '\\layout\\' + str(layout_name) + '.txt'
        txt_file = open(layout_path,'r') 
        txt_file_content = txt_file.readline()
        txt_file.close()
        txt_file_content = eval(txt_file_content)
        print(layout_name)
        print(layout_path)
        print(txt_file_content)
        

        print(self.textEdit_4.toPlainText().replace('\\','/'))
        path = str(self.textEdit_4.toPlainText().replace('\\','/'))
        img = Image.open(path)   # .replace('\\','/')
        print(self.textEdit_4.toPlainText().replace('\\','/'))
        arr = np.asarray(img)
        arr = arr[:,:,2]        
        arr = np.asarray(img)
        #arr = remove_transparency(img, bg_colour=(255, 255, 255))
        arr = np.array(arr)
        arr = arr[:,:,2]
        extracted_list = []
        for i in txt_file_content:
            for j in i:
                extracted = arr[int(j[0][1]):int(j[1][1]), 
                            int(j[0][0]):int(j[1][0])]
            #extracted = cv2.resize(extracted,(60,60),interpolation=cv2.INTER_CUBIC)
                extracted_list.append(extracted)# from segement data
        path = self.cwd.replace('\\','/')
        path = path + '/temp_img_folder'
        print(path)
        image_files = os.listdir(str(path))
        print(image_files)
        for i in image_files:
            os.remove(path + '/'+i)
        #for root, dirs, files in os.walk(path + '/temp_img_folder'):
            #for file in files:
                #os.remove(os.path)
        #os.makedirs(str(path) + '/temp_img_folder')
        print(arr)
        print(path)
        for i in enumerate(extracted_list):
            im = Image.fromarray(i[1])
            im.save(path + '/' + str(i[0]) + '.png')
        
        path2 = self.cwd.replace('\\','/')
        json_file = open(path2 + '/modelA-E.json','r')
        loaded_model_json = json_file.read()
        json_file.close()
        loaded_model = model_from_json(loaded_model_json)
        loaded_model.load_weights(path2 + '/A-E_model.h5')
        image_files = os.listdir(str(path2 + '/temp_img_folder'))
        print(image_files)
        image_files2 = []
        for i in image_files:
            image_files2.append(int(i.replace('.png','')))
        image_files2 = sorted(image_files2)
        image_files2 = [str(x)+'.png' for x in image_files2]
        print(image_files2)        
        temp_image_files_path = []
        for i in image_files2:
            temp_image_files_path.append(path+'/'+i)
        print(temp_image_files_path)
        self.results = []
        for i in temp_image_files_path:
            img = Image.open(i)   # .replace('\\','/')
            arr = np.asarray(img)
            #arr = arr[:,:,2]        
            #arr = np.asarray(img)
        #arr = remove_transparency(img, bg_colour=(255, 255, 255))
            arr = np.array(arr)
            #arr = arr[:,:,2]
            resized = cv2.resize(arr,(60,60),interpolation=cv2.INTER_CUBIC)
            resized = resized.reshape(1,1,60,60)
            result = loaded_model.predict(resized)
            self.results.append(result)
        print(self.results)
        output = self.show_result(self.results)

            #extracted = cv2.resize(extracted,(60,60),interpolation=cv2.INTER_CUBIC)
        #results = loaded_model.predict(extracted_list[0])
        #print(results)
        
        #model = load_model(path + '/A-E_model.h5')
        
        
        
    
    def saving_segment(self):
        self.segement_data = []
        self.segement_data.append(self.plots.segment_data)
        print(self.segement_data)
        fileName_choose, filetype = QFileDialog.getSaveFileName(None,  
                                    "文件保存",  
                                    self.cwd, # 起始路径 
                                    "All Files (*);;Text Files (*.txt)")  

        if fileName_choose == "":
            print("\n取消选择")
            return

        print("\n你选择要保存的文件为:")
        print(fileName_choose)
        print("文件筛选器类型: ",filetype)
        file = open(fileName_choose,'w') 
        file.write(str(self.segement_data)) 
        file.close()
        name = fileName_choose.split('/')
        self.combo.addItem(name[-1].replace('.txt',''))
        
    def selectfile(self):
        fileName_choose, filetype = QFileDialog.getOpenFileName(None,  
                                 "选取文件",  
                                    self.cwd, # 起始路径 
                                    "All Files (*);;png Files (*.png)")   # 设置文件扩展名过滤,用双分号间隔

        if fileName_choose == "":
            print("\n取消选择")
            return
    
        print("\n你选择的文件为:")
        print(fileName_choose)
        print("文件筛选器类型: ",filetype)
        self.textEdit_4.setText(str(fileName_choose))
        
    def load_layout(self):
        path = self.cwd
        print(path)
        path2 = path + '/layout'
        layout_files = os.listdir(str(path2))
        print(layout_files)
        for i in layout_files:
            self.combo.addItem(i.replace('.txt',''))
        
        


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    #sys.exit(app.exec_())

