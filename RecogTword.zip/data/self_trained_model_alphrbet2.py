# -*- coding: utf-8 -*-
"""
Created on Sat Jul 21 19:23:27 2018

@author: Nody
"""


import cv2
import os
import glob
import numpy as np
from scipy import misc
from PIL import Image

def remove_transparency(im, bg_colour=(255, 255, 255)):

    # Only process if image has transparency (http://stackoverflow.com/a/1963146)
    if im.mode in ('RGBA', 'LA') or (im.mode == 'P' and 'transparency' in im.info):

        # Need to convert to RGBA if LA format due to a bug in PIL (http://stackoverflow.com/a/1963146)
        alpha = im.convert('RGBA').split()[-1]

        # Create a new background image of our matt color.
        # Must be RGBA because paste requires both images have the same format
        # (http://stackoverflow.com/a/8720632  and  http://stackoverflow.com/a/9459208)
        bg = Image.new("RGBA", im.size, bg_colour + (255,))
        bg.paste(im, mask=alpha)
        return bg

    else:
        return im

loop_file = ['A','B','C','D','E','F','G','H','I','J','K','L','M',
             'N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
loop_file = ['A','B','C','D','E','N']
img_dir = "C:/Users/Nody/Desktop/alphabets/Latin/"   
data = []
for i in loop_file:
    img_dir = img_dir + i +'/'
    #data_path = os.path.join(img_dir,'*g')
    #files = glob.glob(data_path)
    files2 = os.listdir(img_dir)
    small_list = []
    for f1 in files2:
        img = Image.open(img_dir+f1)
        arr = np.asarray(img)
        arr = remove_transparency(img, bg_colour=(255, 255, 255))
        arr = np.array(arr)
        arr = arr[:,:,2]
        arr = cv2.resize(arr,(60,60),interpolation=cv2.INTER_CUBIC)
        #arr.resize(60,60)
        #img.resize(278,278)
        small_list.append((arr,i))
    data.append(small_list)
    img_dir = "C:/Users/Nody/Desktop/alphabets/Latin/" 


label_data = []
for i in data:
    for j in i:
        label_data.append(j[1])
        
image_data = []
for i in data:
    for j in i:
        image_data.append(j[0])
image_data2 = np.array([image_data])
image_data2 = image_data2.reshape(2981,1,60,60)
del data

from numpy import array
from numpy import argmax
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
# define example

values = array(label_data)
print(values)
# integer encode
label_encoder = LabelEncoder()
integer_encoded = label_encoder.fit_transform(values)
print(integer_encoded)
# binary encode
onehot_encoder = OneHotEncoder(sparse=False)
integer_encoded = integer_encoded.reshape(len(integer_encoded), 1)
onehot_encoded = onehot_encoder.fit_transform(integer_encoded)




import numpy
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.utils import np_utils
from keras import backend as K
K.set_image_dim_ordering('th')
 
# define the larger model
def larger_model():
	# create model
	model = Sequential()
	model.add(Conv2D(30, (5, 5), input_shape=(1, 60, 60), activation='relu'))
	model.add(MaxPooling2D(pool_size=(2, 2)))
	model.add(Conv2D(15, (3, 3), activation='relu'))
	model.add(MaxPooling2D(pool_size=(2, 2)))
	model.add(Dropout(0.2))
	model.add(Flatten())
	model.add(Dense(128, activation='relu'))
	model.add(Dense(50, activation='relu'))
	model.add(Dense(6, activation='softmax')) #num_classes
	# Compile model
	model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
	return model
# Final evaluation of the model
#scores = model.evaluate(X_test, y_test, verbose=0)    
# Larger CNN for the MNIST Dataset



# =============================================================================
# print(onehot_encoded)
# # invert first example
# inverted = label_encoder.inverse_transform([argmax(onehot_encoded[0, :])])
# print(inverted)
# 
# =============================================================================


# build the model
model = larger_model()
# Fit the model
model.fit(image_data2, onehot_encoded, epochs=30, batch_size=200)

model.save_weights(r"C:\Users\Nody\Desktop\alphabets\A-E_model.h5")

# =============================================================================
# img = Image.open(r'C:\Users\Nody\Desktop\alphabets\Latin\B\58aa0c3aa9a16.png') # B
# arr = np.asarray(img)
# arr = remove_transparency(img, bg_colour=(255, 255, 255))
# arr = np.array(arr)
# arr = arr[:,:,2]
# arr = cv2.resize(arr,(60,60),interpolation=cv2.INTER_CUBIC)
# arr2 = np.array([arr])
# arr2 = arr2.reshape(1,1,60,60)
# model.predict(arr2)
# 
# =============================================================================


# =============================================================================
# Out[31]: 
# array([[2.8660833e-03, 1.8580962e-03, 4.3479316e-03, 5.0384599e-05,
#         9.9087745e-01]], dtype=float32)
# a = [2.8660833e-03, 1.8580962e-03, 4.3479316e-03, 5.0384599e-05,
#         9.9087745e-01]        
# a2 = max(a)
# a2
# Out[34]: 0.99087745
# 
# =============================================================================



# =============================================================================
# # fix random seed for reproducibility
# seed = 7
# numpy.random.seed(seed)
# # load data
# (X_train, y_train), (X_test, y_test) = mnist.load_data()
# # reshape to be [samples][pixels][width][height]
# X_train = X_train.reshape(X_train.shape[0], 1, 28, 28).astype('float32')
# X_test = X_test.reshape(X_test.shape[0], 1, 28, 28).astype('float32')
# # normalize inputs from 0-255 to 0-1
# X_train = X_train / 255
# X_test = X_test / 255
# # one hot encode outputs
# y_train = np_utils.to_categorical(y_train)
# y_test = np_utils.to_categorical(y_test)
# num_classes = y_test.shape[1]  
#     
#     
# =============================================================================
    
    
    
    
    
    
# =============================================================================
# cv2.imshow('l', np.array(img,dtype = np.float32))
# cv2.waitKey()
# =============================================================================
# =============================================================================
# from PIL import Image
# from resizeimage import resizeimage
# 
# f = Image.open(r"C:\Users\Nody\Desktop\alphabets\Latin\A\58ac46ff5c2a1.png")
# 
# 
# from skimage import color
# from skimage import io
# img = color.rgb2gray(io.imread(r"C:\Users\Nody\Desktop\alphabets\Latin\A\58ac46ff5c2a1.png"))
# 
# 
# from PIL import Image 
# image_file = Image.open(r"C:\Users\Nody\Desktop\alphabets\Latin\A\58ac46ff5c2a1.png") # open colour image
# image_file = image_file.convert('1') # convert image to black and white
# 
# 
# 
# =============================================================================
# import numpy as np
# import matplotlib.pyplot as plt
# from PIL import Image
# # 
# fname = r"C:\Users\Nody\Desktop\alphabets\Latin\A\58ac46ff5c2a1.png"
# image = Image.open(fname)
# arr = np.asarray(image)
# =============================================================================
# 
# 
# def remove_transparency(im, bg_colour=(255, 255, 255)):
# 
#     # Only process if image has transparency (http://stackoverflow.com/a/1963146)
#     if im.mode in ('RGBA', 'LA') or (im.mode == 'P' and 'transparency' in im.info):
# 
#         # Need to convert to RGBA if LA format due to a bug in PIL (http://stackoverflow.com/a/1963146)
#         alpha = im.convert('RGBA').split()[-1]
# 
#         # Create a new background image of our matt color.
#         # Must be RGBA because paste requires both images have the same format
#         # (http://stackoverflow.com/a/8720632  and  http://stackoverflow.com/a/9459208)
#         bg = Image.new("RGBA", im.size, bg_colour + (255,))
#         bg.paste(im, mask=alpha)
#         return bg
# 
#     else:
#         return im
#     
# =============================================================================
# arr = remove_transparency(image, bg_colour=(255, 255, 255))
# arr = np.asarray(arr)
# arr = arr[:,:,2]
# =============================================================================
# =============================================================================
