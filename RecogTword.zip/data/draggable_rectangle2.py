# -*- coding: utf-8 -*-
"""
Created on Sat Jul 21 23:35:10 2018

@author: Nody
"""

import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import skimage.io as io


class Annotate(object):
    def __init__(self,img_path):
        I = io.imread(img_path)
        plt.imshow(I)
        self.ax = plt.gca()
        self.rect = Rectangle((0,0), 1, 1, fill=None)
        self.x0 = None
        self.y0 = None
        self.x0_0 = None
        self.y0_0 = None
        self.x1 = None
        self.y1 = None
        self.pressed = False
        self.segment_data = []
        self.ax.add_patch(self.rect)
        self.ax.figure.canvas.mpl_connect('button_press_event', self.on_press)
        self.ax.figure.canvas.mpl_connect('button_release_event', self.on_release)
        self.ax.figure.canvas.mpl_connect('motion_notify_event', self.follow_cursor)

    def on_press(self, event):
        self.pressed = True
        print ('press')
        self.x0 = event.xdata
        self.y0 = event.ydata
        print(self.x0)
        print(self.y0)


    def on_release(self, event):
        print ('release')
        self.x1 = event.xdata
        self.y1 = event.ydata
        self.rect.set_width(self.x1 - self.x0)
        self.rect.set_height(self.y1 - self.y0)
        self.rect.set_xy((self.x0, self.y0))
        self.segment_data.append(((self.x0, self.y0),(self.x1,self.y1)))
        self.pressed = False
        #self.ax.figure.canvas.draw()
        
    def follow_cursor(self, event):
        if self.pressed == True:
            print ('following')
            self.x0_0 = event.xdata
            self.y0_0 = event.ydata
            print(self.x0_0)
            print(self.y0_0)
            self.rect.set_width(self.x0_0 - self.x0)
            self.rect.set_height(self.y0_0 - self.y0)
            self.rect.set_xy((self.x0, self.y0))
            self.ax.figure.canvas.draw()

image_object = Annotate()
plt.show()





# =============================================================================
# import matplotlib.pyplot as plt
# 
# fig, ax = plt.subplots()
# text = ax.text(0.5, 0.5, 'event', ha='center', va='center', fontdict={'size': 20})
# 
# def call_back(event):
#     info = 'name:{}\n button:{}\n x,y:{},{}\n xdata,ydata:{}{}'.format(event.name, event.button,event.x, event.y,event.xdata, event.ydata)
#     text.set_text(info)
#     fig.canvas.draw_idle()
# 
# 
# fig.canvas.mpl_connect('button_press_event', call_back)
# fig.canvas.mpl_connect('button_release_event', call_back)
# fig.canvas.mpl_connect('motion_notify_event', call_back)
# 
# plt.show()
# 
# =============================================================================
