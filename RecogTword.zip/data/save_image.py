# -*- coding: utf-8 -*-
"""
Created on Sun Jul 22 01:46:39 2018

@author: Nody
"""


import numpy as np
from PIL import Image
img = Image.open(r'C:\Users\Nody\Desktop\alphabets\58aa0c29a6cf5.png')
arr = np.asarray(img)
arr = arr[:,:,2]

arr = np.asarray(img)
#arr = remove_transparency(img, bg_colour=(255, 255, 255))
arr = np.array(arr)
arr = arr[:,:,2]

extracted = arr[7:229,37:215]  # from segement data
im = Image.fromarray(extracted)
im.save(r"C:\Users\Nody\Desktop\alphabets\B.png")


